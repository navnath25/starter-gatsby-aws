**To delete a snapshot**

This example command deletes a snapshot with the snapshot ID of ``snap-1234567890abcdef0``. If the command succeeds, no output is returned.

Command::

  aws ec2 delete-snapshot --snapshot-id snap-1234567890abcdef0
